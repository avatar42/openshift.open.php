package dea.spamRescue;

import com.microsoft.jdbc.sqlserver.SQLServerDriver;
import dea.common.Display;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Extends GeekToolsHI to use MS SQL server instead of HSQLDB.
 * <br> Create for table is as follows:
 * CREATE TABLE [dbo].[hostInfo] (
 * [hostName] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
 * [abuseEmail] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [hostIP] [varchar] (16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [nic] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [contact] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [status] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [lastChk] [datetime] NULL ,
 * [cnt] [int] NULL ,
 * [type] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
 * [created] [datetime] NULL ,
 * [lastrec] [datetime] NULL
 * ) ON [PRIMARY]
 * GO
 */
public class GeekToolsMSHI extends GeekToolsHI {
    /**
     * Get DB connection
     *
     * @return Connection
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public Connection initDB() throws SQLException, ClassNotFoundException, InstantiationException,
            IllegalAccessException {

        display.dprint(METH_ENTER, "initDB() - Persistent");

        DriverManager.registerDriver(new SQLServerDriver());
        return DriverManager.getConnection("jdbc:Microsoft:sqlserver://localhost:1433;DatabaseName=" + DBNAME,
                "hostinfo", "h0st1nf0");
    }

    /**
     * **************************************************************************
     * Run from command line. Primarily for testing
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("USAGE:GeekToolsMSHI hostName|hostIP whoisURL -clear");
        } else {
            try {
                HostInfo hi = new GeekToolsMSHI();
                Display.setDebug(Display.DEBUG_ALL);
                Connection cConnection = hi.initDB();
                if (args.length > 2) {
                    if ("-clear".equals(args[2]))
                        hi.clearDB(cConnection);
                }
                hi.load(cConnection, args[0]);
                hi.whois(args[0], args[1]);
                if (hi.getHostName() != null)
                    hi.store(cConnection);
                int tm = hi.ping();
                if (tm > -1)
                    System.out.println("pinged port:" + tm);
                else
                    System.out.println("Host is not responding:");

                System.out.println(hi.toString());

                System.out.println("Main Done");
            } catch (SQLException e) {
                display.dprint(ERROR, "Exception caught", e);

            } catch (ClassNotFoundException e) {
                display.dprint(ERROR, "Exception caught", e);

            } catch (InstantiationException e) {
                display.dprint(ERROR, "Exception caught", e);

            } catch (IllegalAccessException e) {
                display.dprint(ERROR, "Exception caught", e);

            }
        }
    }
}
