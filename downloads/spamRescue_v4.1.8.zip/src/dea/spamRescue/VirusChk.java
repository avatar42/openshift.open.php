package dea.spamRescue;

import java.util.StringTokenizer;

/**
 * Class for determining the type of virus received.
 * <br>
 * Based roughly on procmail filters at http://www.kanon.net/~jhardin/email-tools/local-rules.procmail
 * User: dea
 * Date: Apr 11, 2004
 * Time: 10:33:42 AM
 *
 * @author David Abigt
 *         <p/>
 *         Rev 1.0.1 Add W32.Sober.I@mm basic checker.<br>
 */
public class VirusChk {
    /**
     * Version of this class
     */
    public static final String VERSION = "Version 1.1";

    private boolean iframe = false;
    private boolean contentTypeMixed = false;
    private boolean contentTypeAlt = false;
    private boolean contentTypeEXE = false;
    private boolean contentTypeAudio = false;
    private boolean contentTypeWav = false;
    private boolean contentTypeMidi = false;
    private boolean contentTypeHtml = false;
    private boolean contentTypeDown = false;
    private boolean contentTypeGif = false;
    private boolean badTransID = false;
    private boolean contentTypeOctet = false;
    private boolean contentDisEXE = false;
    private boolean contentDisAttach = false;
    private boolean encoding64 = false;
    private boolean sircamA = false;
    private boolean sircamB = false;
    private boolean sircamC = false;
    private boolean klezA = false;
    private boolean seeZip = false;
    private boolean fromAdmin = false;
    private boolean fromSwen = false;
    private boolean toSwen = false;
    private boolean subSwen = false;
    private boolean yourAcct = false;
    private boolean seeAttach = false;
    private boolean soBigCont = false;
    private boolean soBigFCont = false;
    private boolean msgZip = false;
    private String subject = "";

    public boolean contains(String line, String key) {
        return (line.indexOf(key) > -1);
    }

    public VirusChk(SpamInfo si) {
        StringTokenizer st = new StringTokenizer(si.getSpamText(), "\n", false);
        boolean foundFrom = false;
        while (st.hasMoreTokens()) {
            String s = st.nextToken() + "\n";
            if (!foundFrom) {
                if (s.startsWith("Subject:") || s.startsWith("SUBJECT:")) {
                    subject = s;
                    if (contains(s, "your account"))
                        yourAcct = true;
                    // ^(SUBJECT:|Subject:.*([Uu]pdate|[Uu]pgrade|[Pp]atch|[Bb]ug|[Ee]rror|[Cc]ritical|[Ss]ecurity))
                    String tmp = s.toLowerCase();
                    if (contains(tmp, "update") || contains(tmp, "upgrade") || contains(tmp, "patch") || contains(tmp, "bug") ||
                            contains(tmp, "critical") || contains(tmp, "security") || contains(tmp, "error"))
                        subSwen = true;

                } else if (contains(s, "Content-Type:")) {
                    if (contains(s, "multipart/mixed"))
                        contentTypeMixed = true;

                    if (contains(s, "multipart/alternative"))
                        contentTypeAlt = true;

                    if (contains(s, "application/octet-stream"))
                        contentTypeOctet = true;

                    if (contains(s, ".EXE"))
                        contentTypeEXE = true;

                    if (contains(s, "message.zip"))
                        msgZip = true;

                    if (contains(s, "audio/"))
                        contentTypeAudio = true;

                    if (contains(s, "audio/x-wav"))
                        contentTypeWav = true;

                    if (contains(s, "audio/x-midi"))
                        contentTypeMidi = true;

                    if (contains(s, "text/html"))
                        contentTypeHtml = true;

                    if (contains(s, "image/gif"))
                        contentTypeGif = true;

                    if (contains(s, "application/x-msdownload"))
                        contentTypeDown = true;

                    //your_details|application|document|screensaver|movie
                    if (contains(s, ".zip") && (contains(s, "your_details") || contains(s, "application") ||
                            contains(s, "document") || contains(s, "movie") || contains(s, "screensaver")))
                        soBigCont = true;

                    //your_details|details|application|document.*|movie.*|wicked_scr|your_document|thank_you
                    if ((contains(s, ".zip") || contains(s, ".scr") || contains(s, ".pif")) && (contains(s, "your_details") || contains(s, "details") ||
                            contains(s, "document") || contains(s, "movie") || contains(s, "application") ||
                            contains(s, "wicked_scr") || contains(s, "your_document") || contains(s, "thank_you")))
                        soBigFCont = true;

                } else if (contains(s, "Content-Disposition:")) {
                    if (contains(s, ".EXE"))
                        contentDisEXE = true;

                    if (contains(s, "attachment"))
                        contentDisAttach = true;

                    if (contains(s, "message.zip"))
                        msgZip = true;

                    //your_details|application|document|screensaver|movie
                    if (contains(s, ".zip") && (contains(s, "your_details") || contains(s, "application") ||
                            contains(s, "document") || contains(s, "movie") || contains(s, "screensaver")))
                        soBigCont = true;

                    //your_details|details|application|document.*|movie.*|wicked_scr|your_document|thank_you
                    if ((contains(s, ".zip") || contains(s, ".scr") || contains(s, ".pif")) && (contains(s, "your_details") || contains(s, "details") ||
                            contains(s, "document") || contains(s, "movie") || contains(s, "application") ||
                            contains(s, "wicked_scr") || contains(s, "your_document") || contains(s, "thank_you")))
                        soBigFCont = true;

                } else if (contains(s, "Content-Transfer-Encoding:")) {
                    if (contains(s, "base64"))
                        encoding64 = true;

                } else if (contains(s, "Content-ID:")) {
                    if (contains(s, "<EA4DMGBP9p>"))
                        badTransID = true;

                } else if (contains(s, "From:") || contains(s, "FROM:")) {
                    if (contains(s, "admin@"))
                        fromAdmin = true;
                    String tmp = s.toLowerCase();
                    //^(FROM:|From:.*(MS|Microsoft|[Ss]torage|MAILER-DAEMON@|[Aa]dmin|[Dd]aemon|[Tt]echnical|[Pp]ostmaster))
                    if (contains(s, "MS") || contains(tmp, "storage") || contains(tmp, "daemon") || contains(tmp, "technical") || contains(tmp, "postmaster") || contains(s, "Microsoft"))
                        fromSwen = true;

                } else if (contains(s, "To:") || contains(s, "TO:")) {
                    String tmp = s.toLowerCase();
                    //^(TO:|To:.*(" "|[Cc]lient|[Cc]ustomer|[Cc]onsumer|[Pp]artner|[Rr]ecipient|[Rr]eceiver|[Uu]ser))
                    if (contains(tmp, "client") || contains(tmp, "customer") || contains(tmp, "partner") || contains(tmp, "recipient") || contains(tmp, "user"))
                        toSwen = true;

                } else if (s.startsWith("Please see the attached zip file for details")) {
                    seeZip = true;
                } else if (contains(s, " see the attached ") && contains(s, " file for details")) {
                    seeAttach = true;
                } else if (contains(s, "Attachment: No Virus found") ||
                        contains(s, "++++++ MailTo:") ||
                        contains(s, "Who_could_suspect_something_like_that")) {
                    si.setVirusType("W32.Sober.I@mm");
                    si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.sober.i@mm.html");
                }

                if (contains(s, "<iframe"))
                    iframe = true;

                if (contains(s, "AAAAGgU0NhbTMyABCDTUlN"))
                    sircamA = true;

                if (contains(s, "AAAAAaBTQ2FtMzIAEINNSU1F"))
                    sircamB = true;

                if (contains(s, "ABkAAAABoFNDYW0zMgAQg01J"))
                    sircamC = true;

                if (s.startsWith("TVqQAAMAAAAEAAAA"))
                    klezA = true;

            }
        }

        if (contentTypeMixed && contentTypeEXE && contentDisEXE) {
            si.setVirusType("anonymous executable");
            si.setVirus(true);
        }

        if (contentTypeWav && badTransID && encoding64) {
            si.setVirusType("BadTrans worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.badtrans.b@mm.html");
            si.setVirus(true);
        }

        if (contentTypeMixed && contentDisAttach && encoding64 && (sircamA || sircamB || sircamC)) {
            si.setVirusType("SirCam worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.sircam.worm@mm.html");
            si.setVirus(true);
        }

        if (contentTypeAlt && iframe && contentTypeAudio && encoding64 && klezA) {
            if (si.getSpamText().length() > 100000) {
                si.setVirusType("Klez worm");
                si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.klez.removal.tool.html");
            } else {
                si.setVirusType("BugBear worm");
                si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.bugbear@mm.removal.tool.html");
            }
            si.setVirus(true);
        }

        if (contentTypeAlt && contentTypeOctet && encoding64 && klezA && (subject.indexOf("special") > 0 || subject.indexOf("very") > 0)) {
            si.setVirusType("Klez worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.klez.removal.tool.html");
            si.setVirus(true);
        }

        if (seeZip && contentTypeMixed && contentDisAttach && encoding64 && soBigCont) {
            si.setVirusType("SoBig worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.sobig.e@mm.html");
            si.setVirus(true);
        }

        if (!seeZip && seeAttach && contentTypeMixed && contentDisAttach && encoding64 && soBigFCont) {
            si.setVirusType("SoBig.F worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.sobig.f@mm.html");
            si.setVirus(true);
        }

        if (contentTypeMixed && fromAdmin && yourAcct && contentDisAttach && encoding64 && msgZip) {
            si.setVirusType("MiMail worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.mimail.a@mm.html");
            si.setVirus(true);
        }

        if (fromSwen && toSwen && subSwen && encoding64 && (contentTypeMidi || contentTypeWav || contentTypeHtml || contentTypeGif || contentTypeDown)) {
            si.setVirusType("swen variant worm");
            si.setVirusInfo("see http://securityresponse.symantec.com/avcenter/venc/data/w32.swen.a@mm.html");
            si.setVirus(true);
        }

    }

}
