package dea.spamRescue;

import dea.common.Display;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.Timestamp;

/**
 * A whois extracting class. (See spamRescue.properties file)<br>
 * This version is for use with GeekTools Whois Proxy.<br>
 * If this does not work with your whois then you wee need to create your own.<br>
 * <br>
 * Rev 1.4 When scanning abuse contact and no abuse@ found then use shortest email address. (Mainly to make testing easier.)<br>
 * Rev 1.3 Look for anti-spam as well as abuse when looking for abuse email.<br>
 * Rev 1.2 Add code to handle when nothing comes back from the whois. Also checks for data up to 120 times every 1/2 sec before calling
 *  read so the read call will not hang with no data or wait forever on down sites.<br>
 * Rev 1.1 Add better detection of problem entries on whois pages.<br>
 * Put string following ERROR: into status field.<br>
 *
 * @author David Abigt
 */

public class GeekToolsHI extends HostInfo {
    /**
     * GeekToolsHI version number
     */
    public static final String VERSION = "Version 1.3";
    public static int MAXTRIES = 5;
    public static int WAITSECS = 500;

    /**
     * The method for contacting a whois interface, extracting abuse contact info and loading this bean with that info
     * @param site
     * @param url
     *
     */
    public void whois(String site, String url) {
        display.dprint(METH_ENTER, "whois(String site, String url)");
        display.dprint(METH_ENTER, "site", site);
        display.dprint(METH_ENTER, "url", url);
        if (site == null || site.trim().length() == 0)
            return;
        StringBuffer sb = null;
        // mainly to fix bad data from previous test runs
        // postmaster@ seems to be the default and can show up randomly in the abuse contact list.
        // Even if the domain is invalid.
        // Sometimes it's a link instead of and email address.
        // The code now searches the list for and valid email and it any contain the word abuse that one is used
        //  instead of the first or last one as previous version used.
        if (this.abuseEmail != null && (abuseEmail.indexOf('@') == -1 || abuseEmail.startsWith("postmaster")))
            abuseEmail = null;
        try {
            int loop = 0;
            while (loop < MAXTRIES) {
                sb = new StringBuffer();
                try {
                    URL urlConn = new URL(url + site);
                    display.dprint(METH_DETAIL, "protocal", urlConn.getProtocol());
                    display.dprint(METH_DETAIL, "host", urlConn.getHost());
                    display.dprint(METH_DETAIL, "port", urlConn.getPort());
                    display.dprint(METH_DETAIL, "file", urlConn.getFile());
                    display.dprint(METH_DETAIL, "ref", urlConn.getRef());
                    HttpURLConnection con = (HttpURLConnection) urlConn.openConnection();
                    display.dprint(METH_DETAIL, "con.connect()");
                    con.connect();
                    display.dprint(METH_EXT, "Calling con.getContentEncoding()");
                    String encoding = con.getContentEncoding();

                    // Construct a Reader appropriate for that encoding
                    BufferedReader in;
                    display.dprint(METH_EXT, "Creating BufferedReader");
                    if (encoding == null) {
                        in = new BufferedReader(
                                new InputStreamReader(urlConn.openStream()));
                    } else {
                        in = new BufferedReader(
                                new InputStreamReader(urlConn.openStream(), encoding));
                    }
                    char[] buf = new char[8192];  // 8K char buffer should be enough to read in 1 go
                    int charsRead;
                    display.dprint(METH_EXT, "Reading whois page from server");
                    int sleep = 0;
                    while (!in.ready()) {
                        Thread.sleep(WAITSECS);
                        sleep++;
                        if (sleep > 120)
                            throw new Exception("Sleep exceeded");
                    }
                    while ((charsRead = in.read(buf)) != -1) {
                        //display.dprint(METH_EXT, "Read:",buf);
                        sb.append(buf, 0, charsRead);
                    }
                    break;
                } catch (Exception io) {
                    loop++;
                    display.dprint(ERROR, "Caught Exception trying to get abuse entry for:" + site + "\n", io);
                    if (loop == MAXTRIES)
                        throw new Exception("Giving up on whois");
                }
            }
            display.dprint(METH_DETAIL, "Page read into buffer");
            String page = sb.toString();
            BufferedReader dis = new BufferedReader(new StringReader(page));
            boolean foundNic = false;
            while (dis.ready()) {
                String s = dis.readLine();// block till we the 1st line
                if (s == null) // in theory should not happen but did
                    break;
                display.dprint(METH_EXT, "Read:", s);
                sb.append(s + "\n"); // save in case we don't find abuse line on first pass
                if (s.indexOf("whois.abuse.net") > 0) {
                    display.dprint(METH_DETAIL, "Found Abuse header");
                    int start = s.indexOf("?query=");
                    if (start > -1) {
                        int end = s.indexOf(";", start + 7);
                        if (end > -1) {
                            String host = s.substring(start + 7, end).trim();
                            if (isIP(host))
                                setHostIP(host);
                            else
                                setHostName(host);
                            start = s.indexOf("?query=", end);
                            if (start > -1) {
                                end = s.indexOf(";", start + 7);
                                if (end > -1) {
                                    host = s.substring(start + 7, end).trim();
                                    if (isIP(host))
                                        setHostIP(host);
                                    else
                                        setHostName(host);
                                }
                            }
                        }
                    }
                } else if (s.indexOf("Unable to find any TLD information") > 0) {
                    setNic("Domain not found");
                    setAbuseEmail(null);
                    break;
                } else if (s.indexOf("IP Range Reserved by") > 0) {
                    int start = s.indexOf("IP Range Reserved by");
                    start = s.indexOf(">", start + 20);
                    if (start > -1) {
                        int end = s.indexOf("<", start + 2);
                        if (end > -1)
                            setNic(s.substring(start + 1, end));
                        else
                            setNic("Not found");
                    }
                    setStatus("IP Range Reserved");
                    setAbuseEmail(null);
                    break;
                } else if (s.indexOf("ERROR:") > 0) {
                    int start = s.indexOf("ERROR:");
                    String msg = s.substring(start + 6);
                    if (msg.length() > 254)
                        msg = msg.substring(0, 254);
                    setStatus(msg);
                    break;

                } else if (s.indexOf("Server used for this query") > 0) {
                    foundNic = true;
                    int start = s.indexOf("[");
                    if (start > -1) {
                        int end = s.indexOf("]", start);
                        if (end > -1)
                            setNic(s.substring(start + 1, end).trim());
                    }
                } else if (s.indexOf("abuseinformation") > 0) {

                    int start = s.indexOf("mailto:");
                    // use first email if none of them have abuse in the name
                    while (start > -1) {
                        int end = s.indexOf("\"", start + 7);// pull from link not display
                        if (end > -1) {
                            String am = s.substring(start + 7, end).trim();
                            if (am.indexOf('@') > 0 && (abuseEmail == null || am.indexOf("abuse") > -1 ||
                                    am.indexOf("anti-spam") > -1 || am.length() < abuseEmail.length()))
                                abuseEmail = am;
                        }
                        start = s.indexOf("mailto:", end);
                    }
                } else if (s.indexOf("abuse@") > 0 || s.indexOf("anti-spam@") > 0) {
                    int start = s.indexOf("mailto:");
                    if (start > -1) {
                        start = s.indexOf(">", start);
                        if (start > -1) {
                            int end = s.indexOf("<", start);
                            if (end > -1)
                                contact = s.substring(start + 1, end).trim();
                        }
                    }
                } else if (contact == null && (s.indexOf("mail:") > 0 || s.indexOf("ontact:") > 0 || s.indexOf("ontact:") > 0 || s.indexOf("mailto:") > 0)) {
                    int start = s.indexOf("mailto:");
                    if (start > -1) {
                        start = s.indexOf(">", start);
                        if (start > -1) {
                            int end = s.indexOf("<", start);
                            if (end > -1)
                                contact = s.substring(start + 1, end).trim();
                        }
                    }
                } else if (foundNic && (s.indexOf("Abuse") > 0 || s.indexOf("abuse") > 0)) {
                    display.dprint(METH_DETAIL, "Found Abuse stanza");
                    int start = s.indexOf("mailto:");
                    while (s != null && start == -1) {
                        start = s.indexOf("mailto:");
                        if (start == -1) {
                            s = dis.readLine();// block till we the 1st line
                            display.dprint(METH_EXT, "Read:", s);
                        }
                    }
                    if (start > -1) {
                        start = s.indexOf(">", start);
                        if (start > -1) {
                            int end = s.indexOf("<", start);
                            if (end > -1) {
                                contact = s.substring(start + 1, end).trim();
                                display.dprint(METH_DETAIL, "Found Abuse email", contact);
                            }
                        }
                    }
                } else if (s.indexOf("spam") > 0) {
                    int start = s.indexOf("mailto:");
                    if (start > -1) {
                        start = s.indexOf(">", start);
                        if (start > -1) {
                            int end = s.indexOf("<", start);
                            if (end > -1)
                                contact = s.substring(start + 1, end).trim();
                        }
                    }
                } else if (s.indexOf("tatus:") > 0) {
                    int start = s.indexOf("tatus:");
                    if (start > -1) {
                        setStatus(s.substring(start + 6).trim());
                    }
                }
            }
            display.dprint(METH_VARS, "hostName:", hostName);
            if (hostName == null) {
                setHostName(site);
            }
            display.dprint(METH_VARS, "abuseEmail:", abuseEmail);
            if (abuseEmail == null)
                abuseEmail = contact;

        } catch (Exception io) {
            display.dprint(ERROR, "Caught Exception trying to get abuse entry for:" + site + "\n", io);
        }
        lastChk = new Timestamp(System.currentTimeMillis());
        display.dprint(METH_EXIT, "Returning from whois(String site, String url)", this);
        return;
    }

    /*****************************************************************************
     * Run from command line. Primarily for testing
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("USAGE:GeekToolsHI hostName|hostIP whoisURL -clear");
        } else {
            try {
                HostInfo hi = new GeekToolsHI();
                Display.setDebug(Display.DEBUG_ALL);
                Connection cConnection = hi.initDB();
                if (args.length > 2) {
                    if (args[2].equals("-clear"))
                        hi.clearDB(cConnection);
                }
                hi.load(cConnection, args[0]);
                hi.whois(args[0], args[1]);
                if (hi.getHostName() != null)
                    hi.store(cConnection);
                int tm = hi.ping();
                if (tm > -1)
                    System.out.println("pinged port:"+tm);
                else
                    System.out.println("Host is not responding:");

                System.out.println(hi.toString());

                System.out.println("Main Done");
            } catch (Exception ex) {
                System.out.println("Caught Exception:" + ex.getMessage());
                ex.printStackTrace();
            }
        }
        System.exit(0);
    }

}
